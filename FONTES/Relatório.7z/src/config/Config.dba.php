<?php

define("HOST", "localhost");
define("DATABASE", "projetoppw");
define("USER", "root");
define("PASS", "enju");

$hpd = "mysql:host=".HOST.";port=3306;dbname=".DATABASE;
